import { EvidenceWebPageVectorStore } from "../evidenceWebPage.js";

const store = new EvidenceWebPageVectorStore();
await store.testQuery();