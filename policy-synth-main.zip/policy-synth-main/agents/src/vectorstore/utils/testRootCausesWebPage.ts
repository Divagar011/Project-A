import { RootCauseWebPageVectorStore } from "../rootCauseWebPage.js"

const store = new RootCauseWebPageVectorStore();
await store.testQuery();