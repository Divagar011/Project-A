import { WebPageVectorStore } from "../webPage.js";

const store = new WebPageVectorStore();
await store.testQuery();