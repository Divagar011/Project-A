export {};
//# sourceMappingURL=destroyQueue.d.ts.map