export declare class PsIngestionConstants {
    static ingestionMainModel: PsBaseAIModelConstants;
    static ingestionRankingModel: PsBaseAIModelConstants;
}
//# sourceMappingURL=ingestionConstants.d.ts.map