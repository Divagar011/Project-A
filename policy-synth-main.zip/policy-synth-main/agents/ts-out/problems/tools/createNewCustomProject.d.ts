export {};
//# sourceMappingURL=createNewCustomProject.d.ts.map