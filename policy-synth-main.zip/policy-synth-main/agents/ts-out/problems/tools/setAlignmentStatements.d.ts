export {};
//# sourceMappingURL=setAlignmentStatements.d.ts.map