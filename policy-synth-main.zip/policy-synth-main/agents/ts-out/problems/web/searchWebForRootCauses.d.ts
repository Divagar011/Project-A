import { SearchWebProcessor } from "../../solutions/web/searchWeb.js";
export declare class SearchWebForRootCausesProcessor extends SearchWebProcessor {
    searchCounter: number;
    searchWeb(): Promise<void>;
    process(): Promise<void>;
}
//# sourceMappingURL=searchWebForRootCauses.d.ts.map