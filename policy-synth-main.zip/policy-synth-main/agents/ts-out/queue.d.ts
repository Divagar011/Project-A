import winston from 'winston';
import './problems/problemsProcessor.js';
import './solutions/solutions.js';
import './policies/policies.js';
declare const logger: winston.Logger;
export { logger };
//# sourceMappingURL=queue.d.ts.map