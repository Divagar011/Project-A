import { BaseAgentProcessor } from "../baseAgentProcessor.js";
export declare class AgentSolutions extends BaseAgentProcessor {
    memory: PsBaseMemoryData;
    setStage(stage: PsMemoryStageTypes): Promise<void>;
    process(): Promise<void>;
}
//# sourceMappingURL=solutions.d.ts.map