export {};
//# sourceMappingURL=deleteSolutionImage.d.ts.map